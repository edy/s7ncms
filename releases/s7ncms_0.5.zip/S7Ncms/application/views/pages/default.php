<h1><?php echo $page->title ?></h1>
<?php echo $page->intro ?>
<?php echo $page->body ?>