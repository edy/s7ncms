<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'no_table'                        => 'Конфигурираната табела за сесии, %s, не е пронајдена.',
	'driver_not_supported'            => 'Потребниот драјвер за сесии, %s, не е пронајден.',
	'driver_must_implement_interface' => 'Драјверите за сесии мора да го имплементират интерфејсот Session_Driver.'
);