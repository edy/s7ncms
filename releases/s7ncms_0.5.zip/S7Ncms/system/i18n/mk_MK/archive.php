<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'driver_not_supported' => 'Потребниот Archive драјвер, %s, не е поддржан.',
	'driver_implements'    => 'Во потребниот Archive драјвер, %s, нема имплементирано Archive_Driver.',
	'directory_unwritable' => 'Во директориумот во кој сакате да ја зачувате датотеката, %s, неможе да се запишува. Корегирајте ги дозволите (permissions) и пробајте повторно.',
	'filename_conflict'    => 'Потребната архива со име, %s, веќе постои и не може да се запишува во неа. Избришете ја конфликтната датотека и пробајте повторно.'
);