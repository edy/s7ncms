<?php defined('SYSPATH') or die('No se permite acceder directamente a este archivo.');

$lang = array
(
	'acceso',
	'arte',
	'equipamiento',
	'pescado',
	'comida',
	'calor',
	'información',
	'dinero',
	'musica',
	'noticias',
	'polución',
	'arroz',
	'arena',
	'series',
	'oveja',
	'sms',
	'especies',
	'trafico',
	'entendimiento',
	'trabajo'
);