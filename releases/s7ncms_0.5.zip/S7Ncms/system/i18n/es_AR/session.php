<?php defined('SYSPATH') or die('No se permite acceder directamente a este archivo.');

$lang = array
(
	'no_table'                        => 'La tabla de configuraccion de sessiones, %s, no fue encontrada.',
	'driver_not_supported'            => 'El driver de sessiones, %s, no fue encontrado.',
	'driver_must_implement_interface' => 'Los driver de sessiones deben implementar la interfase Session_Driver.'
);