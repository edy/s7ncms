<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'benchmarks'   => 'Pomiar wydajności',
	'post_data'    => 'Dane typu POST',
	'no_post'      => 'Brak danych typu POST',
	'session_data' => 'Dane sesji',
	'no_session'   => 'Brak danych sesji',
	'queries'      => 'Zapytania do bazy danych',
	'no_queries'   => 'Brak zapytań',
	'no_database'  => 'Baza danych nie jest załadowana',
);
