<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'undefined_group'       => '配置文件中未定义组 %s .',
	'error'                 => 'SQL错误: %s',
	'connection'            => '连接数据库失败: %s',
	'driver_not_supported'  => '数据库驱动 %s 不存在.',
	'invalid_dsn'           => '无效 DSN: %s',
	'must_use_set'          => '缺少 SET 语句.',
	'must_use_where'        => '缺少 WHERE 语句.',
	'must_use_table'        => '数据库表未赋值.'
);