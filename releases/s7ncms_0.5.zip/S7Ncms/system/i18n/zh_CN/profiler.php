<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'benchmarks'   => 'Benchmarks',
	'post_data'    => 'Post数据',
	'no_post'      => '无post数据',
	'session_data' => 'Session数据',
	'no_session'   => '无session数据',
	'queries'      => '数据库查询',
	'no_queries'   => '无查询语句',
	'no_database'  => '数据库未加载',
);
