<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'driver_not_supported' => '请求的 %s 驱动,不支持.',
	'driver_implements'    => '请求的 %s 驱动, 未实现Archive_Driver接口.',
	'directory_unwritable' => '请求写目录 %s 权限不足, 无写权限. 请设置好权限后重试.',
	'filename_conflict'    => '请求的文件 %s, 已存在且只读. 请删除冲突文件后重试.'
);