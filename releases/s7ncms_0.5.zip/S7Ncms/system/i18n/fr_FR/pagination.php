<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'page'     => 'page',
	'pages'    => 'pages',
	'item'     => 'résultat',
	'items'    => 'résultats',
	'of'       => 'de',
	'first'    => 'premier',
	'last'     => 'dernier',
	'previous' => 'précédant',
	'next'     => 'suivant',
);