<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'requires_mcrypt'   => 'Afin de pouvoir utiliser la librairie d\'encryption (Encrypt library) mcrypt doit être activé.',
	'no_encryption_key' => 'Afin de pouvoir utiliser la librairie d\'encryption (Encrypt library) vous devez définir une clé d\'encryption dans votre fichier de configuration.'
);
