<?php defined('SYSPATH') or die('No direct script access.');
/**
 * File: Hooks
 *
 * Options:
 *  enable   - Enable or disable hooks. Setting this option to TRUE will enable
 *             all hooks. By using an array of hook filenames, you can control
 *             which hooks are enabled. Setting this option to FALSE disables hooks.
 */
$config = array
(
	'enable' => FALSE
);