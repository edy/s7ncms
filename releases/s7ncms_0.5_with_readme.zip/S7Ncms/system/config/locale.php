<?php defined('SYSPATH') or die('No direct access allowed.');
/**
 * File: Locale
 *  Localization settings.
 *
 * Options:
 *  language - Language name, only en_US is supported by default
 *  timezone - Locale timezone, see <http://php.net/timezones>
 */
$config = array
(
	'language' => 'en_US',
	'timezone' => ''
);