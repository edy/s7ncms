<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'requires_mcrypt'   => '使用Encrypt库类, 必须开启mcrypt.',
	'no_encryption_key' => '使用Encrypt库类, 必须在配置文件中设定加密关键字.'
);
