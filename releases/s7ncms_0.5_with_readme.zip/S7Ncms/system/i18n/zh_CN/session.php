<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'no_table'                        => 'Session数据表 %s, 不存在.',
	'driver_not_supported'            => '请求的session驱动, %s, 不存在.',
	'driver_must_implement_interface' => 'Session必须实现Session_Driver接口.'
);