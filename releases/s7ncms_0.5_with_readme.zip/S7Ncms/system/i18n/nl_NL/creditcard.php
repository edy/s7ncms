<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'required'       => 'Enkele vereiste velden werden niet ingevuld.'
);