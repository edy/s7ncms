<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'no_table'                        => 'De session tabel, %s, werd niet gevonden.',
	'driver_not_supported'            => 'De opgevraagde session driver, %s, werd niet gevonden.',
	'driver_must_implement_interface' => 'Session drivers moeten de Session_Driver interface implementeren.'
);