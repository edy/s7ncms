<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'general_error' => 'Er vond een fout plaats bij het verzenden van de e-mail.'
);