<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'page'     => 'pagina',
	'pages'    => 'pagina\'s',
	'item'     => 'item',
	'items'    => 'items',
	'of'       => 'van',
	'first'    => 'eerste',
	'last'     => 'laatste',
	'previous' => 'vorige',
	'next'     => 'volgende',
);
