<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'requires_mcrypt'   => 'Aby użyć bibliotekę szyfrowania należy włączyć mcrypt.',
	'no_encryption_key' => 'Aby użyć biblioteki szyfrowania należy zdefiniować klucz szyfrujący w pliku konfiguracji.',
);
