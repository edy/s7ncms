<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'page'     => 'strona',
	'pages'    => 'stron',
	'item'     => 'elementy',
	'items'    => 'elementów',
	'of'       => 'z',
	'first'    => 'pierwszy',
	'last'     => 'ostatni',
	'previous' => 'poprzedni',
	'next'     => 'następny',
);
