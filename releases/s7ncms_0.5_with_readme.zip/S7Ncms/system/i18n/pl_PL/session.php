<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'no_table'                        => 'Nie znaleziono ustawionej tablicy sesji %s.',
	'driver_not_supported'            => 'Nie znaleziono wymaganego sterownika sesji %s.',
	'driver_must_implement_interface' => 'Sterownik sesji musi mieć zaimplementowany interfejs "Session_Driver".',
);