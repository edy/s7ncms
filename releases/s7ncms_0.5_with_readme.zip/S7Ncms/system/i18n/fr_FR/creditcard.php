<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'required'       => 'Certains champs requis n\'ont pas été remplis.'
);