<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'general_error' => 'Une erreur est survenue lors de l\'envoi de votre message.'
);