<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'no_table'                        => 'The configured session table, %s, was not found.',
	'driver_not_supported'            => 'The requested session driver, %s, was not found.',
	'driver_must_implement_interface' => 'Session drivers must implement the Session_Driver interface.'
);