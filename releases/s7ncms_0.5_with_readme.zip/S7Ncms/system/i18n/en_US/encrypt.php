<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'requires_mcrypt'   => 'To use the Encrypt library, mcrypt must be enabled.',
	'no_encryption_key' => 'To use the Encrypt library, you need to set a encryption key in your config file.'
);
