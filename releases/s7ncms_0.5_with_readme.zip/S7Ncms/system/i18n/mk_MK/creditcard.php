<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'required'       => 'Одредени обавезни полиња не се напишани.'
);