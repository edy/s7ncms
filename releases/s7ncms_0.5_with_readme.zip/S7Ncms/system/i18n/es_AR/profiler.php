<?php defined('SYSPATH') or die('No se permite acceder directamente a este archivo.');

$lang = array
(
	'benchmarks'   => 'Benchmarks',
	'post_data'    => 'Datos Posteados',
	'no_post'      => 'No hay datos posteados',
	'session_data' => 'Datos de Session',
	'no_session'   => 'No hay datos de session',
	'queries'      => 'Consultas a la Base de Datos',
	'no_queries'   => 'No hay Consultas a la Base de Datos',
	'no_database'  => 'No se encuentra la Base de Datos',
);
