<?php defined('SYSPATH') or die('No se permite acceder directamente a este archivo.');

$lang = array
(
	'page'     => 'página',
	'pages'    => 'páginas',
	'item'     => 'item',
	'items'    => 'items',
	'of'       => 'de',
	'first'    => 'primero',
	'last'     => 'ultimo',
	'previous' => 'anterior',
	'next'     => 'siguiente',
);
