<?php echo $page->intro ?>
<?php echo $page->body ?>