<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Enable or disable hooks. Setting this option to TRUE will enable
 * all hooks. By using an array of hook filenames, you can control
 * which hooks are enabled. Setting this option to FALSE disables hooks.
 */
$config['enable'] = array('domain', 'routes');