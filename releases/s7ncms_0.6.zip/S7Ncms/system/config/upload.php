<?php defined('SYSPATH') or die('No direct access allowed.');
/**
 * Relative to your index file.
 */
$config['upload_directory'] = '@upload';

/**
 * Remove spaces from filenames.
 */
$config['remove_spaces'] = TRUE;