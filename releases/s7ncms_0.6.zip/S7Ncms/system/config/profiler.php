<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Show benchmarks.
 */
$config['benchmarks'] = TRUE;

/**
 * Show database queries.
 */
$config['database'] = TRUE;

/**
 * Show POST data.
 */
$config['post'] = TRUE;

/**
 * Show session data.
 */
$config['session'] = TRUE;