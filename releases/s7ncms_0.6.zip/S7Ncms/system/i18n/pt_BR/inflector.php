<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'acesso',
	'arte',
	'equipamento',
	'peixe',
	'comida',
	'calor',
	'informacão',
	'dinheiro',
	'música',
	'notícias',
	'poluiicão',
	'arroz',
	'areia',
	'séries',
	'ovelha',
	'sms',
	'espécies',
	'tráfego',
	'compreensão',
	'trabalho'
);