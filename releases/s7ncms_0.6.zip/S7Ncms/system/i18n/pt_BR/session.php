<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'no_table'                        => 'A tabela, %s, configurada para manipular a sessão, não foi encontrada.',
	'driver_not_supported'            => 'O driver de sessão solicitado, %s, não foi encontrado.',
	'driver_must_implement_interface' => 'Os drivers de Sessão devem implementar a interface Session_Driver.');