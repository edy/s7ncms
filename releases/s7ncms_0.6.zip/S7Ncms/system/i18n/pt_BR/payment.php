<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'required'       => 'Alguns campos requisitados n�o foram informados: %s',
	'gateway_connection_error' => 'Um erro ocorreu durante a conex�o com o gateway de pagamento. Por favor, contate o webmaster caso o problema persista.',
	'invalid_certificate' => 'O arquivo de certificado � inv�lido.'
);