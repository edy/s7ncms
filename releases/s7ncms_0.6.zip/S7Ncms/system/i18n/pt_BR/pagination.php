<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'page'     => 'página',
	'pages'    => 'páginas',
	'item'     => 'item',
	'items'    => 'itens',
	'of'       => 'de',
	'first'    => 'primeiro',
	'last'     => 'último',
	'previous' => 'anterior',
	'next'     => 'próximo',
);
