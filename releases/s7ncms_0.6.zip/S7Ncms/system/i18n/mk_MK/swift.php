<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'general_error' => 'Грешка при испраќање на емаил порака.'
);