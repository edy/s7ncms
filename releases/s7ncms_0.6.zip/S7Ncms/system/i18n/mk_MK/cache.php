<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'driver_not_supported' => 'Cache драјверот %s не постои.',
	'unwritable'           => 'Во конфигурираната локација за кеширање, <tt>%s</tt>, не може да се запишува.',
	'resources'            => 'Кеширање на ресурсите е невозможно, бидејќи ресурсите не можат да се серијализират.',
);