<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'undefined_group'       => 'Групата %s не е дефинирана во твојата конфигурација.',
	'error'                 => 'Се појави SQL грешка: %s',
	'connection'            => 'Грешка при конектирање со датабазата: %s',
	'driver_not_supported'  => 'Драјверот за датабазата %s не постои.',
	'invalid_dsn'           => 'DSN-от кој го имате напишано не е валиден: %s',
	'must_use_set'          => 'Мора да напишете SET услов во ова query.',
	'must_use_where'        => 'Мора да напишете WHERE услов во ова query.',
	'must_use_table'        => 'Мора да ја напишете табелата во датабазата во ова query.',
	'not_implemented'       => 'Повиканата метода, %s, не е поддржана од овој драјвер.'
);