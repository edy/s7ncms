<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'driver_not_supported' => 'De %s cache driver bestaat niet.',
	'unwritable'           => 'De geconfigureerde opslaglocatie, <tt>%s</tt>, is niet schrijfbaar.',
	'resources'            => 'Het cachen van resources is onmogelijk omdat resources niet geserialized kunnen worden.',
	'driver_error'         => '%s',
);