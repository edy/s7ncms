<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'requires_mcrypt'   => 'Om de Encrypt library te gebruiken, moet mcrypt ingeschakeld zijn.',
	'no_encryption_key' => 'Om de Encrypt library te gebruiken, moet je een encryption key zetten in je config bestand.'
);
