<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'driver_not_supported' => '7h3 r3qu3573d 4rch1v3 dr1v3r, %s, 15 n07 5upp0r73d.',
	'driver_implements'    => '7h3 r3qu3573d 4rch1v3 dr1v3r, %s, d035 n07 1mp|3m3n7 4rch1v3_Dr1v3r.',
	'directory_unwritable' => '7h3 d1r3c70ry y0u r3qu3573d 70 54v3 7h3 f1|3 1n, %s, 15 unwr174b|3. P|3453 c0rr3c7 7h3 p3rm15510n5 4nd 7ry 4641n.',
	'filename_conflict'    => '7h3 r3qu3573d 4rch1v3 f1|3n4m3, %s, 4|r34dy 3x1575 4nd 15 n07 wr174b|3. P|3453 r3m0v3 7h3 c0nf|1c71n6 f1|3 4nd 7ry 4641n.'
);