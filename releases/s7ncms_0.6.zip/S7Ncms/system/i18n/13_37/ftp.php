<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'no_connection'       => 'Un4b|3 70 |0c473 4 v4|1d c0nn3c710n 1D.  P|3453 m4k3 5ur3 y0u 4r3 c0nn3c73d b3f0r3 p3f0rm1n6 4ny f1|3 r0u71n35.',
	'unable_to_connect'   => 'Un4b|3 70 c0nn3c7 70 y0ur F7P 53rv3r u51n6 7h3 5upp|13d h057n4m3.',
	'unable_to_login'     => 'Un4b|3 70 |061n 70 y0ur F7P 53rv3r.  P|3453 ch3ck y0ur u53rn4m3 4nd p455w0rd.',
	'unable_to_makdir'    => 'Un4b|3 70 cr3473 7h3 d1r3c70ry y0u h4v3 5p3c1f13d.',
	'unable_to_changedir' => 'Un4b|3 70 ch4n63 d1r3c70r135.',
	'unable_to_chmod'     => 'Un4b|3 70 537 f1|3 p3rm15510n5.  P|3453 ch3ck y0ur p47h.  N073: 7h15 f347ur3 15 0n|y 4v41|4b|3 1n PHP 5 0r h16h3r.',
	'unable_to_upload'    => 'Un4b|3 70 up|04d 7h3 5p3c1f13d f1|3.  P|3453 ch3ck y0ur p47h.',
	'no_source_file'      => 'Un4b|3 70 |0c473 7h3 50urc3 f1|3.  P|3453 ch3ck y0ur p47h.',
	'unable_to_remame'    => 'Un4b|3 70 r3n4m3 7h3 f1|3.',
	'unable_to_delete'    => 'Un4b|3 70 d3|373 7h3 f1|3.',
	'unable_to_move'      => 'Un4b|3 70 m0v3 7h3 f1|3.  P|3453 m4k3 5ur3 7h3 d3571n4710n d1r3c70ry 3x1575.'	
);
