<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'no_table'                        => '7h3 c0nf16ur3d 535510n 74b|3, %5, w45 n07 f0und.',
	'driver_not_supported'            => '7h3 r3qu3573d 535510n dr1v3r, %5, w45 n07 f0und.',
	'driver_must_implement_interface' => '535510n dr1v3r5 mu57 1mp|3m3n7 7h3 535510n_Dr1v3r 1n73rf4c3.'
);