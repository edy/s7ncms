<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	E_KOHANA             => array( 1, 'Fr4m3w0rk 3rr0r',   'P|3453 ch3ck 7h3 K0h4n4 d0cum3n74710n f0r 1nf0rm4710n 4b0u7 7h3 f0||0w1n6 3rr0r.'),
	E_PAGE_NOT_FOUND     => array( 1, 'P463 N07 F0und',    '7h3 r3qu3573d p463 w45 n07 f0und. 17 m4y h4v3 m0v3d, b33n d3|373d, 0r 4rch1v3d.'),
	E_DATABASE_ERROR     => array( 1, 'D474b453 3rr0r',    '4 d474b453 3rr0r 0ccurr3d wh1|3 p3rf0rm1n6 7h3 r3qu3573d pr0c3dur3. P|3453 r3v13w 7h3 d474b453 3rr0r b3|0w f0r m0r3 1nf0rm4710n.'),
	E_RECOVERABLE_ERROR  => array( 1, 'R3c0v3r4b|3 3rr0r', '4n 3rr0r w45 d373c73d wh1ch pr3v3n73d 7h3 |04d1n6 0f 7h15 p463. 1f 7h15 pr0b|3m p3r51575, p|3453 c0n74c7 7h3 w3b5173 4dm1n157r470r.'),
	E_ERROR              => array( 1, 'F474| 3rr0r',       ''),
	E_USER_ERROR         => array( 1, 'F474| 3rr0r',       ''),
	E_PARSE              => array( 1, '5yn74x 3rr0r',      ''),
	E_WARNING            => array( 2, 'W4rn1n6 M355463',   ''),
	E_USER_WARNING       => array( 2, 'W4rn1n6 M355463',   ''),
	E_STRICT             => array( 3, '57r1c7 M0d3 3rr0r', ''),
	E_NOTICE             => array( 3, 'Run71m3 M355463',   ''),
);