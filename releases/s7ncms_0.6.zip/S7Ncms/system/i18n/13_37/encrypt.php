<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'requires_mcrypt'   => '70 u53 7h3 3ncryp7 |1br4ry, mcryp7 mu57 b3 3n4b|3d.',
	'no_encryption_key' => '70 u53 7h3 3ncryp7 |1br4ry, y0u n33d 70 537 4 3ncryp710n k3y 1n y0ur c0nf16 f1|3.'
);
