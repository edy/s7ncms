<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'access',
	'art',
	'equipment',
	'fish',
	'food',
	'heat',
	'information',
	'money',
	'music',
	'news',
	'pollution',
	'rice',
	'sand',
	'series',
	'sheep',
	'sms',
	'species',
	'traffic',
	'understanding',
	'work'
);