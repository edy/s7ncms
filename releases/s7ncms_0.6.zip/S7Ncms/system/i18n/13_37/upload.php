<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'userfile_not_set'   => 'Un4b|3 70 f1nd 4 p057 v4r14b|3 c4||3d %s.',
	'file_exceeds_limit' => '7h3 up|04d3d f1|3 3xc33d5 7h3 m4x1mum 4||0w3d 51z3 1n y0ur PHP c0nf16ur4710n f1|3',
	'file_partial'       => '7h3 f1|3 w45 0n|y p4r714||y up|04d3d',
	'no_file_selected'   => 'Y0u d1d n07 53|3c7 4 f1|3 70 up|04d',
	'invalid_filetype'   => '7h3 f1|3 7yp3 y0u 4r3 4773mp71n6 70 up|04d 15 n07 4||0w3d.',
	'invalid_filesize'   => '7h3 f1|3 y0u 4r3 4773mp71n6 70 up|04d 15 |4r63r 7h4n 7h3 p3rm1773d 51z3 (%s)',
	'invalid_dimensions' => '7h3 1m463 y0u 4r3 4773mp71n6 70 up|04d 3xc33d35 7h3 m4x1mum h316h7 0r w1d7h (%s)',
	'destination_error'  => '4 pr0b|3m w45 3nc0un73r3d wh1|3 4773mp71n6 70 m0v3 7h3 up|04d3d f1|3 70 7h3 f1n4| d3571n4710n.',
	'no_filepath'        => '7h3 up|04d p47h d035 n07 4pp34r 70 b3 v4|1d.',
	'no_file_types'      => 'Y0u h4v3 n07 5p3c1f13d 4ny 4||0w3d f1|3 7yp35.',
	'bad_filename'       => '7h3 f1|3 n4m3 y0u 5ubm1773d 4|r34dy 3x1575 0n 7h3 53rv3r.',
	'not_writable'       => '7h3 up|04d d3571n4710n f0|d3r, %5, d035 n07 4pp34r 70 b3 wr174b|3.',
	'error_on_file'      => '3rr0r up|04d1n6 %s:',
	// Error code responses
	'set_allowed'        => 'F0r 53cur17y, y0u mu57 537 7h3 7yp35 0f f1|35 7h47 4r3 4||0w3d 70 b3 up|04d3d.',
	'max_file_size'      => 'F0r 53cur17y, p|3453 d0 n07 u53 MAX_FILE_SIZE 70 c0n7r0| 7h3 m4x1mum up|04d 51z3.',
	'no_tmp_dir'         => 'C0u|d n07 f1nd 4 73mp0r4ry d1r3c70ry 70 wr173 70.',
	'tmp_unwritable'     => 'C0u|d n07 cr3473 wr173 70 7h3 c0nf16ur3d up|04d d1r3c70ry, %s.'
);
