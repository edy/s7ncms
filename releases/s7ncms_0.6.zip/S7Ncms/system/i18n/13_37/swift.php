<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'general_error' => '4n 3rr0r 0ccurr3d wh1|3 53nd1n6 7h3 3m41| m355463.'
);