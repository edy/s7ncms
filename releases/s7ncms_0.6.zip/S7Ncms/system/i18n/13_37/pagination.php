<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'page'     => 'p463',
	'pages'    => 'p4635',
	'item'     => '173m',
	'items'    => '173m5',
	'of'       => '0f',
	'first'    => 'f1r57',
	'last'     => '|457',
	'previous' => 'pr3v10u5',
	'next'     => 'n3x7',
);
