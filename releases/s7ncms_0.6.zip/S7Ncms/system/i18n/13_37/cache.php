<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'driver_not_supported' => '7h3 %s c4ch3 dr1v3r d035 n07 3x157.',
	'unwritable'           => '7h3 c0nf16ur3d 570r463 |0c4710n, <tt>%s</tt>, 15 n07 wr174b|3.',
	'resources'            => 'C4ch1n6 0f r350urc35 15 1mp0551b|3, b3c4u53 r350urc35 c4nn07 b3 53r14|1z3d.',
);