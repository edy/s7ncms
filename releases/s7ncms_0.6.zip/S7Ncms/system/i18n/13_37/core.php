<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'there_can_be_only_one' => '7h3r3 c4n b3 0n|y 0n3 1n574nc3 0f K0h4n4 p3r p463 r3qu357.',
	'uncaught_exception'    => 'Unc4u6h7 %s: %s 1n f1|3 %s 0n |1n3 %s',
	'invalid_method'        => '1nv4|1d m37h0d <tt>%s</tt> c4||3d 1n <tt>%s</tt>.',
	'cannot_write_log'      => 'Y0ur |06.d1r3c70ry c0nf16 53771n6 d035 n07 p01n7 70 4 wr174b|3 d1r3c70ry.',
	'resource_not_found'    => '7h3 r3qu3573d %s, <tt>%s</tt>, c0u|d n07 b3 f0und.',
	'no_default_route'      => 'P|3453 537 4 d3f4u|7 r0u73 1n <tt>c0nf16/r0u735.php</tt>.',
	'no_controller'         => 'K0h4n4 w45 n07 4b|3 70 d373rm1n3 4 c0n7r0||3r 70 pr0c355 7h15 r3qu357: %s',
	'page_not_found'        => '7h3 p463 y0u r3qu3573d, <tt>%s</tt>, c0u|d n07 b3 f0und.',
	'stats_footer'          => '|04d3d 1n {execution_time}  53c0nd5, u51n6 {memory_usage} 0f m3m0ry. 63n3r473d by K0h4n4 v{kohana_version}.',
	'error_message'         => '3rr0r 0ccurr3d 47 <57r0n6>|1n3 %s</57r0n6> 0f <strong>%s</strong>.'
);