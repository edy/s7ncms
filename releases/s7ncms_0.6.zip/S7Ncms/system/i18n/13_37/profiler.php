<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'benchmarks'   => 'B3nchm4rk5',
	'post_data'    => 'P057 D474',
	'no_post'      => 'N0 p057 d474',
	'session_data' => '535510n D474',
	'no_session'   => 'N0 535510n d474',
	'queries'      => 'D474b453 Qu3r135',
	'no_queries'   => 'N0 qu3r135',
	'no_database'  => 'D474b453 n07 |04d3d',
);
