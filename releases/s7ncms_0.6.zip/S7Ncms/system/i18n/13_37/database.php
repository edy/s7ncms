<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'undefined_group'       => '7h3 %s 6r0up 15 n07 d3f1n3d 1n y0ur c0nf16ur4710n.',
	'error'                 => '7h3r3 w45 4n 5Q| 3rr0r: %s',
	'connection'            => '7h3r3 w45 4n 3rr0r c0nn3c71n6 70 7h3 d474b453: %s',
	'driver_not_supported'  => '7h3 %s d474b453 dr1v3r d035 n07 3x157.',
	'invalid_dsn'           => '7h3 D5N y0u 5upp|13d 15 n07 v4|1d: %s',
	'must_use_set'          => 'Y0u mu57 537 4 537 c|4u53 f0r y0ur qu3ry.',
	'must_use_where'        => 'Y0u mu57 537 4 WH3R3 c|4u53 f0r y0ur qu3ry.',
	'must_use_table'        => 'Y0u mu57 537 4 d474b453 74b|3 f0r y0ur qu3ry.',
	'not_implemented'       => '7h3 m37h0d y0u c4||3d, %s, 15 n07 5upp0r73d by 7h15 dr1v3r.'
);