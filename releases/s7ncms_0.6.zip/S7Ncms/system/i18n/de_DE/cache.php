<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'driver_not_supported' => 'Der %s-Cachetreiber existiert nicht.',
	'unwritable'           => 'Der eingestellte Speicherort, <tt>%s</tt>, ist nicht beschreibbar.',
	'resources'            => 'Das Cachen von Ressourcen ist nicht möglich, da diese nicht serialisiert werden können.',
);