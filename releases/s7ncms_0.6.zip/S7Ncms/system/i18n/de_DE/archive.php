<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'driver_not_supported' => 'Der gewählte Archivtreiber, %s, wird nicht unterstützt.',
	'driver_implements'    => 'Der gewählte Archivtreiber, %s, implementiert nicht Archive_Driver.',
	'directory_unwritable' => 'Das Verzeichnis, in dem die Datei gespeichert werden soll, %s, it nicht beschreibbar. Korrigieren Sie bitte die Zugriffsrechte und versuchen Sie es erneut.',
	'filename_conflict'    => 'Der für das Archiv gewählte Dateiname, %s, existiert bereits und ist nicht beschreibbar. Löschen Sie bitte die Datei und versuchen Sie es erneut.'
);