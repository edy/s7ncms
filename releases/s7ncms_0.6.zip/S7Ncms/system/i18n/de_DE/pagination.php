<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'page'     => 'Seite',
	'pages'    => 'Seiten',
	'item'     => 'Element',
	'items'    => 'Elemente',
	'of'       => 'von',
	'first'    => 'Erste',
	'last'     => 'Letzte',
	'previous' => 'Vorherige',
	'next'     => 'Nächste',
);
