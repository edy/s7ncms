<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'no_table'                        => 'Die eingestellte Sessiontabelle, %s, wurde nicht gefunden.',
	'driver_not_supported'            => 'Der geforderte Sessiontreiber, %s, wurde nicht gefunden.',
	'driver_must_implement_interface' => 'Sessiontreiber müssen das Session_Driver-Interface implementieren.'
);