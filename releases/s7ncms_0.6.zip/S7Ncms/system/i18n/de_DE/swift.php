<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'general_error' => 'Fehler beim Senden einer E-Mail aufgetreten.'
);