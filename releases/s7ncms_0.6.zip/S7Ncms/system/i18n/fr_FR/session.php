<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'no_table'                        => 'La table de session %s configurée n\'a pas été trouvée.',
	'driver_not_supported'            => 'Le pilote de session %s n\'a pas été trouvé.',
	'driver_must_implement_interface' => 'Les pilotes de session doivent implémenter l\'interface Session_Driver.'
);