<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'driver_not_supported' => 'Le driver du cache %s n\'existe pas.',
	'unwritable'           => 'Le chemin <tt>%s</tt> configuré pour le cache n\'est pas accessible en écriture.',
	'resources'            => 'La mise en cache des ressources est impossible car elles n\'ont pas pu être sérialisées.',
    'driver_error'         => '%s'
);