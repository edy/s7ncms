<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'driver_not_supported' => 'Wybrany rodzaj archiwizowania: %s nie jest obsługiwany.',
	'driver_implements'    => 'Wybrany rodzaj archiwizowania: %s nie obsługuje Archive_Driver.',
	'directory_unwritable' => 'Katalog %s wybrany do zapisu pliku jest tylko do odczytu. Proszę zmienić uprawnienia i spróbować ponownie.',
	'filename_conflict'    => 'Wybrana nazwa archiwum %s, istnieje i nie może być zapisana. Proszę usunąć plik i spróbować ponownie.',
);