<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'driver_not_supported' => 'Il cache driver %s non esiste.',
	'unwritable'           => 'La cartella di deposito, <tt>%s</tt>, non ha i permessi in scrittura.',
	'resources'            => 'Risorsa non serializzabile. Impossibile immagazzinare.',
);