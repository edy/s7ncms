<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'page'     => 'pagina',
	'pages'    => 'pagine',
	'item'     => 'item',
	'items'    => 'items',
	'of'       => 'di',
	'first'    => 'primo',
	'last'     => 'ultimo',
	'previous' => 'precedente',
	'next'     => 'successivo',
);
