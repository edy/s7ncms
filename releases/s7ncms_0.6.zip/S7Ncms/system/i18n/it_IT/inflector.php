<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'accesso',
	'arte',
	'equipaggiamento',
	'pesce',
	'cibo',
	'calore',
	'informazione',
	'soldi',
	'musica',
	'notizie',
	'inquinamento',
	'riso',
	'sabbia',
	'serie',
	'pecora',
	'sms',
	'specie',
	'traffico',
	'comprensione',
	'lavoro'
);