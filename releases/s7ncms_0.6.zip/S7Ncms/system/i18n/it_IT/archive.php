<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'driver_not_supported' => 'Il driver di archivio richiesto, %s, non è supportato.',
	'driver_implements'    => 'Il driver di archivio richiesto, %s, non implementa Archive_Driver.',
	'directory_unwritable' => 'La cartella in cui si è scelto di salvare il file, %s, è protetta in scrittura. Impostare opportunamente i permessi prima di ritentare.',
	'filename_conflict'    => 'L\'archivio richiesto, %s, è già esistente ed è protetto in scrittura. Ritentare dopo aver rimosso il file in conflitto.'
);