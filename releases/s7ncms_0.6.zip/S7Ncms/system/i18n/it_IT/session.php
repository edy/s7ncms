<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'no_table'                        => 'La tabella di configurazione delle sessioni, %s, non è stata trovata.',
	'driver_not_supported'            => 'Il driver delle sessioni richiesto, %s, non è stato trovato.',
	'driver_must_implement_interface' => 'Il driver delle sessioni deve implementare l\'interfaccia Session_Driver.'
);