<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'driver_not_supported' => 'The %s cache driver does not exist.',
	'unwritable'           => 'The configured storage location, <tt>%s</tt>, is not writable.',
	'resources'            => 'Caching of resources is impossible, because resources cannot be serialized.',
	'driver_error'         => '%s',
);