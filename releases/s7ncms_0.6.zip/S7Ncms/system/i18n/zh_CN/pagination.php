<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'page'     => '页',
	'pages'    => '页',
	'item'     => '条',
	'items'    => '条',
	'of'       => ' / ',
	'first'    => '首页',
	'last'     => '末页',
	'previous' => '前页',
	'next'     => '后页',
);
