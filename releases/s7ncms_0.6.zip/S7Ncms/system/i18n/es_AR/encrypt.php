<?php defined('SYSPATH') or die('No se permite acceder directamente a este archivo.');

$lang = array
(
	'requires_mcrypt'   => 'Para usar la libreria de Encriptación, mcrypt debe estar habilitado.',
	'no_encryption_key' => 'Para usar la libreria de Encriptación, tenes que especificar una llave de encriptación en tu archivo de configuración.'
);
