<?php defined('SYSPATH') or die('No se permite acceder directamente a este archivo.');

$lang = array
(
	'driver_not_supported' => 'El archivo del driver requerido, %s, no tiene soporte.',
	'driver_implements'    => 'El archivo del driver requerido, %s, no implementa Archive_Driver.',
	'directory_unwritable' => 'El directorio en el que intentaste salvar el archivo, %s, no tiene permiso de escritura. Dale permiso de escritura e intenta de nuevo.',
	'filename_conflict'    => 'El archivo, %s, ya existe y no tiene permiso de escritura. Por favor, borrá el archivo en conflicto e intenta de nuevo.'
);