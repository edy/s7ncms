<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Domain name, with the installation directory. Default: localhost/kohana/
 */
$config['site_domain'] = '{site_domain}';