<h1>The End</h1>
<p>You successfully installed S7Ncms!</p>
<p>
	<?php echo html::anchor($url_site, 'Your Website') ?><br />
	<?php echo html::anchor($url_admin, 'Website Administration') ?>
</p>